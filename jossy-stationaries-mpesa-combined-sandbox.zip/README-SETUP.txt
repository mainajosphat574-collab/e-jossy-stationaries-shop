JOSSY STATIONARIES — DARAJA SANDBOX TEST BUILD

IMPORTANT
- This build is for sandbox testing only. It does not enable live collections.
- Keep your existing management site (quiet-puppy-d53b0c) separate. Deploy this folder to the customer shop project beamish-bubblegum-c14eb7.
- Never put Consumer Secret, passkey, or Firebase service account JSON into index.html or send them in chat.
- A Daraja STK request accepted by the API does NOT mean the customer paid. Only callback result code 0 marks an order paid in Firestore.

NETLIFY ENVIRONMENT VARIABLES
In Netlify project beamish-bubblegum-c14eb7 → Site configuration → Environment variables, add:

DARAJA_CONSUMER_KEY = your sandbox Consumer Key
DARAJA_CONSUMER_SECRET = your sandbox Consumer Secret
DARAJA_SHORTCODE = 174379
DARAJA_PASSKEY = the sandbox Lipa na M-Pesa Express passkey copied from the Daraja portal's test credentials/simulator
FIREBASE_SERVICE_ACCOUNT_JSON = the entire service-account JSON text for the Firebase project jossy-stationaries-manager

Firebase service account setup:
1. Open Google Cloud Console for project jossy-stationaries-manager.
2. IAM & Admin → Service Accounts → create a dedicated service account for this Netlify backend.
3. Grant only the minimum Firestore access needed (Firestore data access / Cloud Datastore User may be required; avoid Owner role).
4. Create a JSON key, download it, and paste the entire JSON file contents as the value of FIREBASE_SERVICE_ACCOUNT_JSON in Netlify. Do not upload the JSON into the website folder or share it.
5. Delete the downloaded key file from shared/public locations after securely storing it.

DEPLOY
1. Add the environment variables first and save.
2. Download/extract this ZIP.
3. Deploy the extracted folder contents to the EXISTING customer-shop Netlify site beamish-bubblegum-c14eb7 using Netlify manual deploy. It must include index.html, netlify.toml, package.json, and netlify/functions/.
4. If Netlify drag-and-drop does not install dependencies/build functions, use Netlify's Git-based deploy or Netlify CLI from this folder; Netlify Functions require a build step for the firebase-admin dependency. Do not deploy just index.html.
5. After each environment variable change, trigger a fresh deploy.

TESTING
- Daraja app must have the M-Pesa Express Sandbox product enabled.
- Use only sandbox credentials and sandbox tests. The sandbox may show a prompt but no real money should be collected.
- Check Netlify → Functions logs for start-payment and mpesa-callback.
- Check Firestore orders document: paymentStatus remains unpaid until callback reports success; then it changes to paid and records receipt/amount.
- Callback URL is constructed automatically as https://YOUR-SHOP-DOMAIN/.netlify/functions/mpesa-callback.

LIMITATIONS / BEFORE LIVE
This starter is a sandbox implementation, not a security audit or production-ready payment service. Before live use, add rate limiting, idempotency/replay protection, stronger callback verification/reconciliation, order expiry and support for failed/late callbacks, abuse monitoring, and production Daraja onboarding with your own approved shortcode/Till/Paybill and live passkey. Never mark paid from browser data. Test callback handling and Firestore rules with a developer before accepting real money.
